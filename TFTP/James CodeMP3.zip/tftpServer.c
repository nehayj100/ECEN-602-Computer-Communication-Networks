#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>

#define MAX_FILE_LENGTH 255 
#include "tftpHeader.h"
FILE *fileLog;

int main()
{
    //Create/bind socket:
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    fileLog = fopen("tftp_server.log", "a"); // allow appending to file w/ -a option
    if (fileLog == NULL) 
    {
        perror("Error opening log file");
        exit(EXIT_FAILURE);
    }

    if (sockfd < 0) 
    {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(6969); //defines the port number

    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) 
    {
        perror("Error binding socket");
        close(sockfd); // Close the socket in case of an error
        exit(EXIT_FAILURE);
    }

    //Receive and handle TFTP requests
    while (1)
    {
        // Receive request packet from client
        char buffer[516]; 
        int bytes_received = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &addr_len);
        unsigned short opcode = ntohs(*(unsigned short *)buffer);

        if (bytes_received < 0)
        {
            perror("Error receiving request");
            exit(EXIT_FAILURE);
        }
        // Search data for specific opcode value (RRQ or WRQ)
        if (opcode == 1) 
        {
            RRQ_handle(sockfd, client_addr, buffer, bytes_received);
        } 
        else if (opcode == 2) 
        {
            WRQ_handle(sockfd, client_addr, buffer, bytes_received);
        } 
        else 
        {
            send_illegal_operation_error(sockfd, client_addr);
        }

    }

    fclose(fileLog);
    return 0;
}

