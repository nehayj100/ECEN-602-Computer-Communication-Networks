#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>

#define MAX_FILE_LENGTH 255 
FILE *fileLog;


//Error Packet: Create an error packet with the specified error code and message
void send_error_packet(int sockfd, struct sockaddr_in client_addr, unsigned short error_code, const char *error_message) 
{
    char error_packet[516];
    //First two bytes to indicate it's an error packet
    error_packet[0] = 0;
    error_packet[1] = 5;

    // Set the error code
    error_packet[2] = (error_code >> 8) & 0xFF;
    error_packet[3] = error_code & 0xFF;

    // Copy the error message into the packet
    strncpy(error_packet + 4, error_message, sizeof(error_packet) - 5);

    // Identify packet length
    int packet_length = strlen(error_message) + 5;

    // Send the error to the client
    sendto(sockfd, error_packet, packet_length, 0, (struct sockaddr *)&client_addr, sizeof(client_addr));
}

//File Not Found:
void send_file_not_found_error(int sockfd, struct sockaddr_in client_addr) 
{
    send_error_packet(sockfd, client_addr, 1, "File not found");
}

//Illegal Operation:
void send_illegal_operation_error(int sockfd, struct sockaddr_in client_addr) 
{
    send_error_packet(sockfd, client_addr, 4, "Illegal TFTP operation");
}


//RRQ Function:
void RRQ_handle(int sockfd, struct sockaddr_in client_addr, char *buffer, int bytes_received) 
{
    // Extract opcode and filename from the RRQ packet
    unsigned short opcode = ntohs(*(unsigned short *)buffer);
    char *filename = buffer + 2; // Skip opcode
    char *mode = filename + strlen(filename) + 1; // Skip filename and get mode

    // Check if the mode is "octet" (binary)
    if (strcmp(mode, "octet") != 0) 
    {
        send_illegal_operation_error(sockfd, client_addr);
        return;
    }
        // Check if file exists
    int fd = open(filename, O_RDONLY);
    if (fd < 0) 
    {
        send_file_not_found_error(sockfd, client_addr);
        fflush(fileLog);
        return;
    }
    // Initialize block number
    unsigned short block_num = 1;

    // Read and send the file in data packets
    while (1) 
    {
        char data_packet[516];

        // Read data from the file
        ssize_t bytes_read = read(fd, data_packet + 4, 512); 

        if (bytes_read < 0) 
        {
            //Read error
            perror("Error reading file");
            close(fd);
            return;
        } 
        else if (bytes_read == 0) 
        {
            break;
        }

        // Add opcode (3) and block number to the data packet
        data_packet[0] = 0;
        data_packet[1] = 3;
        data_packet[2] = (block_num >> 8) & 0xFF;
        data_packet[3] = block_num & 0xFF;

        // Send the data packet to the client
        sendto(sockfd, data_packet, bytes_read + 4, 0, (struct sockaddr *)&client_addr, sizeof(client_addr));

        // Increment the block number
        block_num++;

        // Check for ACK from the client (implement ACK handling logic)
    }
    fprintf(fileLog, "Received RRQ from %s for file: %s\n", inet_ntoa(client_addr.sin_addr), filename);
    close(fd);
}


//WRQ Function:
void WRQ_handle(int sockfd, struct sockaddr_in client_addr, char *buffer, int bytes_received) 
{
    // Extract opcode and filename from the WRQ packet
    unsigned short opcode = ntohs(*(unsigned short *)buffer);
    char *filename = buffer + 2; // Skip opcode
    char *mode = filename + strlen(filename) + 1; // Skip filename and get mode

    // Check if the mode is "octet" (binary)
    if (strcmp(mode, "octet") != 0) 
    {
        send_illegal_operation_error(sockfd, client_addr);
        return;
    }

    // Create or open the requested file for writing
    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) 
    {
        fprintf(fileLog, "Error reading file: %s\n", strerror(errno));
        return;
    }

    // Acknowledge the WRQ with an ACK packet
    unsigned short block_num = 0;
    char ack_packet[4];
    ack_packet[0] = 0;
    ack_packet[1] = 4;
    ack_packet[2] = 0;
    ack_packet[3] = 0;
    sendto(sockfd, ack_packet, 4, 0, (struct sockaddr *)&client_addr, sizeof(client_addr));

    // Receive data and write to the file in data packets
    while (1) 
    {
        char data_packet[516];
        socklen_t addr_len = sizeof(client_addr);

        int bytes_received = recvfrom(sockfd, data_packet, sizeof(data_packet), 0, (struct sockaddr *)&client_addr, &addr_len);

        if (bytes_received < 0) 
        {
            perror("Error receiving data packet");
            close(fd);
            return;
        }

        // Extract block number from the received data packet
        unsigned short received_block_num = ntohs(*(unsigned short *)(data_packet + 2));

        // Check received block
        if (received_block_num == (block_num + 1)) 
        {
            // Write data to the file
            ssize_t bytes_written = write(fd, data_packet + 4, bytes_received - 4); // Skip opcode and block number

            if (bytes_written < 0) {
                // Handle write error
                perror("Error writing to file");
                close(fd);
                return;
            }

            // Increment the block number
            block_num++;

            // Check if this is the last data packet
            if (bytes_received < 516) 
            {
                break;
            }

            // Acknowledge the received DATA packet with an ACK packet
            ack_packet[2] = (block_num >> 8) & 0xFF;
            ack_packet[3] = block_num & 0xFF;
            sendto(sockfd, ack_packet, 4, 0, (struct sockaddr *)&client_addr, sizeof(client_addr));
        } 
        else if (received_block_num == block_num) 
        {
            // Duplicate data packet received, retransmit ACK
            sendto(sockfd, ack_packet, 4, 0, (struct sockaddr *)&client_addr, sizeof(client_addr));
        } 
        else 
        {
            fprintf(fileLog, "Unexpected block number received: expected %u, received %u\n", block_num + 1, received_block_num);

        }
    }

    fprintf(fileLog, "Received WRQ from %s for file: %s\n", inet_ntoa(client_addr.sin_addr), filename);
    close(fd);
}

