#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define SERVER_PORT 69
#define MAX_BUFFER_SIZE 512

void handle_rrq(int sockfd, struct sockaddr_in client_addr, char *filename) {
    // Implement the logic to handle RRQ here
    // Open and send the requested file to the client
    // You can use the open(), read(), and sendto() functions to achieve this
    // Ensure proper error handling and packet formatting
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[MAX_BUFFER_SIZE];

    // Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address struct
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(SERVER_PORT);

    // Bind socket to server address
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    printf("TFTP server listening on port %d...\n", SERVER_PORT);

    while (1) {
        // Receive RRQ request from client
        ssize_t received_bytes = recvfrom(sockfd, buffer, MAX_BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &client_addr_len);
        if (received_bytes < 0) {
            perror("Receive error");
            exit(EXIT_FAILURE);
        }

        // Extract the filename from the RRQ packet
        char *filename = NULL;
        if (buffer[1] == 1) { // Check if it is a RRQ packet (opcode 1)
            filename = buffer + 2;
        }

        // Handle RRQ request
        if (filename != NULL) {
            printf("Received RRQ for file: %s\n", filename);
            handle_rrq(sockfd, client_addr, filename);
        }
    }

    // Close the socket (unreachable in this example)
    close(sockfd);
    return 0;
}
